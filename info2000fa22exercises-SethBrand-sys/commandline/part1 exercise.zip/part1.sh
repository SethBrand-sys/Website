mkdir part1/
cd part1/
touch mercury.txt
touch earth.txt
touch venus.txt
touch mars.txt
touch jupiter.txt
touch saturn.txt
touch uranus.txt
touch neptune.txt
mkdir planets/
mv *.txt planets/
mv planets/ solarsystem/
pwd
ls -pal
cd solarsystem/
pwd
ls
cd ..
cd ..
pwd
